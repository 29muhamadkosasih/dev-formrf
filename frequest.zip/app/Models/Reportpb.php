<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Reportpb extends Model
{
    use HasFactory;
    protected $table = 'reportpb';
    protected $guarded = [];
}
