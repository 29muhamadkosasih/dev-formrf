<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReportPPH23 extends Model
{
    use HasFactory;
    protected $table = 'reportpph23';
    protected $guarded = [];
}