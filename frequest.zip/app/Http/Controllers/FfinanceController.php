<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FfinanceController extends Controller
{
    //
}
