<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Form'); ?>
<!-- Invoice table -->

<?php if(auth()->user()->departement_id == 1): ?>

<div class="col-xl-12">
    <div class="card">
        <div class="card-body">
            <div class="row ">
                <div class="col-auto me-auto ">
                    <h5 class="mb-0">Data Pengajuan
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover table-bordered zero-configuration">
                    <thead>
                        <tr style="background-color: skyblue">
                            <th width='10px' style="text-align: center">No</th>
                            <th>Dari</th>
                            <th>Tanggal Kebutuhan</th>
                            <th>Departement</th>
                            <th>Keperluan</th>
                            <th>Untuk</th>
                            <th>Kategori
                                Pengajuan</th>
                            <th>Status</th>
                            <th width='230px' style="text-align: center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $tdpmarketing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <tr>
                            <td style="text-align: center"><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php echo e($data->user->name); ?>

                            </td>
                            <td>
                                <?php echo e(\Carbon\Carbon::parse($data->tanggal_kebutuhan)->format('d-m-Y')); ?>

                            </td>
                            <td>
                                <?php echo e($data->departement->nama_departement); ?>

                            </td>
                            <td>
                                <?php echo e($data->keperluan->name); ?>

                            </td>
                            <td>
                                <?php echo e($data->rujukan->name); ?>

                            </td>
                            <td>
                                <?php echo e($data->kpengajuan->name); ?> </td>
                            <td>
                                <?php switch($data):
                                case ($data->status == 0): ?>
                                <span class="badge bg-secondary">Pending</span>
                                <?php break; ?>
                                <?php case ($data->status == 2): ?>
                                <span class="badge bg-danger">Reject</span>
                                <?php break; ?>
                                <?php case ($data->status == 3): ?>
                                <span class="badge bg-warning">Approve</span>
                                <?php break; ?>
                                <?php default: ?>
                                <span class="badge bg-success">PAID</span>
                                <?php endswitch; ?>
                            </td>
                            <td style="text-align: center">

                                <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                    action="<?php echo e(route('form-checkedman.destroy', $data->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    
                                    <a href="<?php echo e(route('form-checkedman.detail', $data->id)); ?>"
                                        class="btn btn-icon btn-secondary btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-secondary"
                                        data-bs-original-title="Show">
                                        <span class="ti ti-eye"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(route('form-checkedman.edit', $data->id)); ?>"
                                        class="btn btn-icon btn-warning btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-warning"
                                        data-bs-original-title="Edit">
                                        <span class="ti ti-edit"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(url('reject/maker', $data->id)); ?>"
                                        class="btn btn-icon btn-danger btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-danger"
                                        data-bs-original-title="Reject">
                                        <span class="ti ti-x"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(url('approve/maker', $data->id)); ?>"
                                        class="btn btn-icon btn-success btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-success"
                                        data-bs-original-title="Approve">
                                        <span class="ti ti-check"></span>
                                    </a>
                                    
                                    
                                    <button type="submit" class="btn btn-icon btn-danger btn-sm"
                                        data-bs-toggle="tooltip" data-bs-placement="top"
                                        data-bs-custom-class="tooltip-danger" data-bs-original-title="Hapus">
                                        <span class="ti ti-trash"></span>

                                    </button>
                                    
                                </form>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php elseif(auth()->user()->departement_id == 2): ?>
<div class="col-xl-12">
    <div class="card">
        <div class="card-body">
            <div class="row ">
                <div class="col-auto me-auto ">
                    <h5 class="mb-0">Data Pengajuan
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover table-bordered zero-configuration">
                    <thead>
                        <tr style="background-color: skyblue">
                            <th width='10px' style="text-align: center">No</th>
                            <th>Dari</th>
                            <th>Tanggal Kebutuhan</th>
                            <th>Departement</th>
                            <th>Keperluan</th>
                            <th>Untuk</th>
                            <th>Kategori
                                Pengajuan</th>
                            <th>Status</th>
                            <th width='230px' style="text-align: center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $tdpadmin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <tr>
                            <td style="text-align: center"><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php echo e($data->user->name); ?>

                            </td>
                            <td>
                                <?php echo e(\Carbon\Carbon::parse($data->tanggal_kebutuhan)->format('d-m-Y')); ?>

                            </td>
                            <td>
                                <?php echo e($data->departement->nama_departement); ?>

                            </td>
                            <td>
                                <?php echo e($data->keperluan->name); ?>

                            </td>
                            <td>
                                <?php echo e($data->rujukan->name); ?>

                            </td>
                            <td>
                                <?php echo e($data->kpengajuan->name); ?> </td>
                            <td>
                                <?php switch($data):
                                case ($data->status == 0): ?>
                                <span class="badge bg-secondary">Pending</span>
                                <?php break; ?>
                                <?php case ($data->status == 2): ?>
                                <span class="badge bg-danger">Reject</span>
                                <?php break; ?>
                                <?php case ($data->status == 3): ?>
                                <span class="badge bg-warning">Approve</span>
                                <?php break; ?>
                                <?php default: ?>
                                <span class="badge bg-success">PAID</span>
                                <?php endswitch; ?>
                            </td>
                            <td style="text-align: center">

                                <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                    action="<?php echo e(route('form-checkedman.destroy', $data->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    
                                    <a href="<?php echo e(route('form-checkedman.detail', $data->id)); ?>"
                                        class="btn btn-icon btn-secondary btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-secondary"
                                        data-bs-original-title="Show">
                                        <span class="ti ti-eye"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(route('form-checkedman.edit', $data->id)); ?>"
                                        class="btn btn-icon btn-warning btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-warning"
                                        data-bs-original-title="Edit">
                                        <span class="ti ti-edit"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(url('reject/maker', $data->id)); ?>"
                                        class="btn btn-icon btn-danger btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-danger"
                                        data-bs-original-title="Reject">
                                        <span class="ti ti-x"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(url('approve/maker', $data->id)); ?>"
                                        class="btn btn-icon btn-success btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-success"
                                        data-bs-original-title="Approve">
                                        <span class="ti ti-check"></span>
                                    </a>
                                    
                                    
                                    <button type="submit" class="btn btn-icon btn-danger btn-sm"
                                        data-bs-toggle="tooltip" data-bs-placement="top"
                                        data-bs-custom-class="tooltip-danger" data-bs-original-title="Hapus">
                                        <span class="ti ti-trash"></span>

                                    </button>
                                    
                                </form>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php elseif(auth()->user()->departement_id == 3): ?>
<div class="col-xl-12">
    <div class="card">
        <div class="card-body">
            <div class="row ">
                <div class="col-auto me-auto ">
                    <h5 class="mb-0">Data Pengajuan
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover table-bordered zero-configuration">
                    <thead>
                        <tr style="background-color: skyblue">
                            <th width='10px' style="text-align: center">No</th>
                            <th>Dari</th>
                            <th>Tanggal Kebutuhan</th>
                            <th>Departement</th>
                            <th>Keperluan</th>
                            <th>Untuk</th>
                            <th>Kategori
                                Pengajuan</th>
                            <th>Status</th>
                            <th width='230px' style="text-align: center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $tdp_op; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <tr>
                            <td style="text-align: center"><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php echo e($data->user->name); ?>

                            </td>
                            <td>
                                <?php echo e(\Carbon\Carbon::parse($data->tanggal_kebutuhan)->format('d-m-Y')); ?>

                            </td>
                            <td>
                                <?php echo e($data->departement->nama_departement); ?>

                            </td>
                            <td>
                                <?php echo e($data->keperluan->name); ?>

                            </td>
                            <td>
                                <?php echo e($data->rujukan->name); ?>

                            </td>
                            <td>
                                <?php echo e($data->kpengajuan->name); ?> </td>
                            <td>
                                <?php switch($data):
                                case ($data->status == 0): ?>
                                <span class="badge bg-secondary">Pending</span>
                                <?php break; ?>
                                <?php case ($data->status == 2): ?>
                                <span class="badge bg-danger">Reject</span>
                                <?php break; ?>
                                <?php case ($data->status == 3): ?>
                                <span class="badge bg-warning">Approve</span>
                                <?php break; ?>
                                <?php default: ?>
                                <span class="badge bg-success">PAID</span>
                                <?php endswitch; ?>
                            </td>
                            <td style="text-align: center">

                                <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                    action="<?php echo e(route('form-checkedman.destroy', $data->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    
                                    <a href="<?php echo e(route('form-checkedman.detail', $data->id)); ?>"
                                        class="btn btn-icon btn-secondary btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-secondary"
                                        data-bs-original-title="Show">
                                        <span class="ti ti-eye"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(route('form-checkedman.edit', $data->id)); ?>"
                                        class="btn btn-icon btn-warning btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-warning"
                                        data-bs-original-title="Edit">
                                        <span class="ti ti-edit"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(url('reject/maker', $data->id)); ?>"
                                        class="btn btn-icon btn-danger btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-danger"
                                        data-bs-original-title="Reject">
                                        <span class="ti ti-x"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(url('approve/maker', $data->id)); ?>"
                                        class="btn btn-icon btn-success btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-success"
                                        data-bs-original-title="Approve">
                                        <span class="ti ti-check"></span>
                                    </a>
                                    
                                    
                                    <button type="submit" class="btn btn-icon btn-danger btn-sm"
                                        data-bs-toggle="tooltip" data-bs-placement="top"
                                        data-bs-custom-class="tooltip-danger" data-bs-original-title="Hapus">
                                        <span class="ti ti-trash"></span>

                                    </button>
                                    
                                </form>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php elseif(auth()->user()->departement_id == 18): ?>
<div class="col-xl-12">
    <div class="card">
        <div class="card-body">
            <div class="row ">
                <div class="col-auto me-auto ">
                    <h5 class="mb-0">Data Pengajuan
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover table-bordered zero-configuration">
                    <thead>
                        <tr style="background-color: skyblue">
                            <th width='10px' style="text-align: center">No</th>
                            <th>Dari</th>
                            <th>Tanggal Kebutuhan</th>
                            <th>Departement</th>
                            <th>Keperluan</th>
                            <th>Untuk</th>
                            <th>Kategori
                                Pengajuan</th>
                            <th>Status</th>
                            <th width='230px' style="text-align: center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $tkki; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <tr>
                            <td style="text-align: center"><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php echo e($data->user->name); ?>

                            </td>
                            <td>
                                <?php echo e(\Carbon\Carbon::parse($data->tanggal_kebutuhan)->format('d-m-Y')); ?>

                            </td>
                            <td>
                                <?php echo e($data->departement->nama_departement); ?>

                            </td>
                            <td>
                                <?php echo e($data->keperluan->name); ?>

                            </td>
                            <td>
                                <?php echo e($data->rujukan->name); ?>

                            </td>
                            <td>
                                <?php echo e($data->kpengajuan->name); ?> </td>
                            <td>
                                <?php switch($data):
                                case ($data->status == 0): ?>
                                <span class="badge bg-secondary">Pending</span>
                                <?php break; ?>
                                <?php case ($data->status == 2): ?>
                                <span class="badge bg-danger">Reject</span>
                                <?php break; ?>
                                <?php case ($data->status == 3): ?>
                                <span class="badge bg-warning">Approve</span>
                                <?php break; ?>
                                <?php default: ?>
                                <span class="badge bg-success">PAID</span>
                                <?php endswitch; ?>
                            </td>
                            <td style="text-align: center">

                                <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                    action="<?php echo e(route('form-checkedman.destroy', $data->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    
                                    <a href="<?php echo e(route('form-checkedman.detail', $data->id)); ?>"
                                        class="btn btn-icon btn-secondary btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-secondary"
                                        data-bs-original-title="Show">
                                        <span class="ti ti-eye"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(route('form-checkedman.edit', $data->id)); ?>"
                                        class="btn btn-icon btn-warning btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-warning"
                                        data-bs-original-title="Edit">
                                        <span class="ti ti-edit"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(url('reject/maker', $data->id)); ?>"
                                        class="btn btn-icon btn-danger btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-danger"
                                        data-bs-original-title="Reject">
                                        <span class="ti ti-x"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(url('approve/maker', $data->id)); ?>"
                                        class="btn btn-icon btn-success btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-success"
                                        data-bs-original-title="Approve">
                                        <span class="ti ti-check"></span>
                                    </a>
                                    
                                    
                                    <button type="submit" class="btn btn-icon btn-danger btn-sm"
                                        data-bs-toggle="tooltip" data-bs-placement="top"
                                        data-bs-custom-class="tooltip-danger" data-bs-original-title="Hapus">
                                        <span class="ti ti-trash"></span>

                                    </button>
                                    
                                </form>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php elseif(auth()->user()->departement_id == 7): ?>
<div class="col-xl-12">
    <div class="card">
        <div class="card-body">
            <div class="row ">
                <div class="col-auto me-auto ">
                    <h5 class="mb-0">Data Pengajuan
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover table-bordered zero-configuration">
                    <thead>
                        <tr style="background-color: skyblue">
                            <th width='10px' style="text-align: center">No</th>
                            <th>Dari</th>
                            <th>Tanggal Kebutuhan</th>
                            <th>Departement</th>
                            <th>Keperluan</th>
                            <th>Untuk</th>
                            <th>Kategori
                                Pengajuan</th>
                            <th>Status</th>
                            <th width='230px' style="text-align: center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $tdp_hr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <tr>
                            <td style="text-align: center"><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php echo e($data->user->name); ?>

                            </td>
                            <td>
                                <?php echo e(\Carbon\Carbon::parse($data->tanggal_kebutuhan)->format('d-m-Y')); ?>

                            </td>
                            <td>
                                <?php echo e($data->departement->nama_departement); ?>

                            </td>
                            <td>
                                <?php echo e($data->keperluan->name); ?>

                            </td>
                            <td>
                                <?php echo e($data->rujukan->name); ?>

                            </td>
                            <td>
                                <?php echo e($data->kpengajuan->name); ?> </td>
                            <td>
                                <?php switch($data):
                                case ($data->status == 0): ?>
                                <span class="badge bg-secondary">Pending</span>
                                <?php break; ?>
                                <?php case ($data->status == 1): ?>
                                <span class="badge bg-danger">Reject</span>
                                <?php break; ?>
                                <?php case ($data->status == 2): ?>
                                <span class="badge bg-info">Approve</span>
                                <?php break; ?>
                                <?php case ($data->status == 3): ?>
                                <span class="badge bg-danger">Cancel</span>
                                <?php break; ?>
                                <?php case ($data->status == 4): ?>
                                <span class="badge bg-primary">Menuggu Konfirmasi Dana</span>
                                <?php break; ?>
                                <?php case ($data->status == 5): ?>
                                <span class="badge bg-success">Konfirmasi Dana Masuk</span>
                                <?php break; ?>

                                <?php case ($data->status == 6): ?>
                                <span class="badge bg-primary">Konfirmasi Pembayaran </span>
                                <?php break; ?>
                                <?php case ($data->status == 7): ?>
                                <span class="badge bg-info">Menuggu Konfirmasi Pengembalian Dana </span>
                                <?php break; ?>

                                <?php default: ?>
                                <span class="badge bg-success">PAID</span>
                                <?php endswitch; ?>
                            </td>
                            <td style="text-align: center">

                                <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                    action="<?php echo e(route('form-checkedman.destroy', $data->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    
                                    <a href="<?php echo e(route('form-checkedman.detail', $data->id)); ?>"
                                        class="btn btn-icon btn-secondary btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-secondary"
                                        data-bs-original-title="Show">
                                        <span class="ti ti-eye"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(route('form-checkedman.edit', $data->id)); ?>"
                                        class="btn btn-icon btn-warning btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-warning"
                                        data-bs-original-title="Edit">
                                        <span class="ti ti-edit"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(url('reject/maker', $data->id)); ?>"
                                        class="btn btn-icon btn-danger btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-danger"
                                        data-bs-original-title="Reject">
                                        <span class="ti ti-x"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(url('approve/maker', $data->id)); ?>"
                                        class="btn btn-icon btn-success btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-success"
                                        data-bs-original-title="Approve">
                                        <span class="ti ti-check"></span>
                                    </a>
                                    
                                    
                                    <button type="submit" class="btn btn-icon btn-danger btn-sm"
                                        data-bs-toggle="tooltip" data-bs-placement="top"
                                        data-bs-custom-class="tooltip-danger" data-bs-original-title="Hapus">
                                        <span class="ti ti-trash"></span>

                                    </button>
                                    
                                </form>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php else: ?>
<div class="col-xl-12">
    <div class="card">
        <div class="card-body">
            <div class="row ">
                <div class="col-auto me-auto ">
                    <h5 class="mb-0">Data Pengajuan
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover table-bordered zero-configuration">
                    <thead>
                        <tr style="background-color: skyblue">
                            <th width='10px' style="text-align: center">No</th>
                            <th>Dari</th>
                            <th>Tanggal Kebutuhan</th>
                            <th>Departement</th>
                            <th>Keperluan</th>
                            <th>Untuk</th>
                            <th>Kategori
                                Pengajuan</th>
                            <th>Status</th>
                            <th width='230px' style="text-align: center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <tr>
                            <td style="text-align: center"><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php echo e($data->user->name); ?>

                            </td>
                            <td>
                                <?php echo e(\Carbon\Carbon::parse($data->tanggal_kebutuhan)->format('d-m-Y')); ?>

                            </td>
                            <td>
                                <?php echo e($data->departement->nama_departement); ?>

                            </td>
                            <td>
                                <?php echo e($data->keperluan->name); ?>

                            </td>
                            <td>
                                <?php echo e($data->rujukan->name); ?>

                            </td>
                            <td>
                                <?php echo e($data->kpengajuan->name); ?> </td>
                            <td>
                                <?php switch($data):
                                case ($data->status == 0): ?>
                                <span class="badge bg-secondary">Pending</span>
                                <?php break; ?>
                                <?php case ($data->status == 2): ?>
                                <span class="badge bg-danger">Reject</span>
                                <?php break; ?>
                                <?php case ($data->status == 3): ?>
                                <span class="badge bg-warning">Approve</span>
                                <?php break; ?>
                                <?php default: ?>
                                <span class="badge bg-success">PAID</span>
                                <?php endswitch; ?>
                            </td>
                            <td style="text-align: center">

                                <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                    action="<?php echo e(route('form-checkedman.destroy', $data->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    
                                    <a href="<?php echo e(route('form-checkedman.detail', $data->id)); ?>"
                                        class="btn btn-icon btn-secondary btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-secondary"
                                        data-bs-original-title="Show">
                                        <span class="ti ti-eye"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(route('form-checkedman.edit', $data->id)); ?>"
                                        class="btn btn-icon btn-warning btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-warning"
                                        data-bs-original-title="Edit">
                                        <span class="ti ti-edit"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(url('reject/maker', $data->id)); ?>"
                                        class="btn btn-icon btn-danger btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-danger"
                                        data-bs-original-title="Reject">
                                        <span class="ti ti-x"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(url('approve/maker', $data->id)); ?>"
                                        class="btn btn-icon btn-success btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-success"
                                        data-bs-original-title="Approve">
                                        <span class="ti ti-check"></span>
                                    </a>
                                    
                                    
                                    <button type="submit" class="btn btn-icon btn-danger btn-sm"
                                        data-bs-toggle="tooltip" data-bs-placement="top"
                                        data-bs-custom-class="tooltip-danger" data-bs-original-title="Hapus">
                                        <span class="ti ti-trash"></span>

                                    </button>
                                    
                                </form>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- /Invoice table -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel\frequest\resources\views/pages/form/checkedman/index.blade.php ENDPATH**/ ?>