<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Form'); ?>
<!-- Invoice table -->
<div class="col-xl-12">
    <div class="card">
        <div class="card-body">
            <div class="row ">
                <div class="col-auto me-auto ">
                    <h5 class="mb-0">Data Pengajuan
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover table-bordered zero-configuration">
                    <thead>
                        <tr style="background-color: skyblue">
                            <th width='10px' style="text-align: center">No</th>
                            <th>Dari</th>
                            <th>Tanggal Kebutuhan</th>
                            <th>Untuk</th>
                            <th>Departement</th>
                            <th>Kategori
                                Pengajuan</th>
                            <th class="text-center">Payment</th>
                            <th>Status</th>
                            <th width='180px' style="text-align: center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <tr>
                            <td style="text-align: center"><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php echo e($data->user->name); ?>

                            </td>
                            <td>
                                <?php echo e(\Carbon\Carbon::parse($data->tanggal_kebutuhan)->format('d-m-Y')); ?>

                            </td>
                            <td>
                                <?php echo e($data->rujukan->name); ?> </td>
                            <td>
                                <?php echo e($data->departement->nama_departement); ?>

                            </td>
                            <td>
                                <?php echo e($data->kpengajuan->name); ?> </td>

                            <td>
                                <?php echo e($data->payment); ?>

                            </td>
                            <td>
                                <?php switch($data):
                                case ($data->status == 0): ?>
                                <span class="badge bg-secondary">Pending</span>
                                <?php break; ?>
                                <?php case ($data->status == 4): ?>
                                <span class="badge bg-success"> RF Telah Approve</span>
                                <?php break; ?>
                                <?php case ($data->status == 5): ?>
                                <span class="badge bg-warning"> Menunggu Konfimasi Pembayaran</span>
                                <?php break; ?>

                                <?php case ($data->status == 6): ?>
                                <span class="badge bg-success">Selesai</span>
                                <?php break; ?>

                                <?php default: ?>
                                <span class="badge bg-info">Process</span>
                                <?php endswitch; ?>
                            </td>
                            <td style="text-align: center">
                                <?php switch($data):
                                case ($data->status == 4): ?>
                                <span class="badge bg-success"> Menunggu Konfirmasi </span>
                                <?php break; ?>

                                <?php case ($data->status == 5): ?>
                                <span class="badge bg-success"> Menunggu Konfimasi Pembayaran</span>
                                <?php break; ?>

                                <?php case ($data->status == 6): ?>
                                <a href="<?php echo e(route('form-approve.viewDetail', $data->id)); ?>"
                                    class="btn btn-icon btn-secondary btn-sm">
                                    <span class="ti ti-eye"></span>
                                </a>
                                <?php break; ?>

                                <?php default: ?>
                                <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                    action="<?php echo e(route('form-approve.destroy', $data->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a href="<?php echo e(route('form-approve.detail', $data->id)); ?>"
                                        class="btn btn-icon btn-secondary btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-secondary"
                                        data-bs-original-title="Detail">
                                        <span class="ti ti-eye"></span>
                                    </a>

                                    

                                    <a href="<?php echo e(route('form-approve.edit', $data->id)); ?>"
                                        class="btn btn-icon btn-warning btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-warning"
                                        data-bs-original-title="Edit">
                                        <span class="ti ti-edit"></span>
                                    </a>

                                    <a href="<?php echo e(url('reject/reject', $data->id)); ?>"
                                        class="btn btn-icon btn-danger btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-danger"
                                        data-bs-original-title="Reject">
                                        <span class="ti ti-x"></span>
                                    </a>
                                    

                                    
                                    <a href="<?php echo e(url('approve/approve', $data->id)); ?>"
                                        class="btn btn-icon btn-success btn-sm" data-bs-toggle="tooltip"
                                        data-bs-placement="top" data-bs-custom-class="tooltip-success"
                                        data-bs-original-title="Approve">
                                        <span class="ti ti-check"></span>
                                    </a>

                                    <button type="submit" class="btn btn-icon btn-danger btn-sm"
                                        data-bs-toggle="tooltip" data-bs-placement="top"
                                        data-bs-custom-class="tooltip-danger" data-bs-original-title="Hapus">
                                        <span class="ti ti-trash"></span>

                                    </button>
                                </form>

                                <?php endswitch; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /Invoice table -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel\frequest\resources\views/pages/form/approve/index.blade.php ENDPATH**/ ?>