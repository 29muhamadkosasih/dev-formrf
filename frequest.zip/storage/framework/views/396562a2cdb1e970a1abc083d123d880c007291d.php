<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title', 'Form'); ?>

<!-- Invoice table -->
<div class="col-xl-12">
    <div class="card">
        <div class="card-body">
            <div class="row ">
                <div class="col-auto me-auto ">
                    <h5 class="mb-0">Data Pengajuan
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover table-bordered zero-configuration">
                    <thead>
                        <tr style="background-color: skyblue">
                            <th width='10px' style="text-align: center">No</th>
                            <th class="text-center">Dari</th>
                            <th class="text-center">Departement</th>
                            <th class="text-center">Payment Method</th>
                            <th class="text-center">Kategori
                                Pengajuan</th>
                            <th class="text-center">Jumlah (Rp)</th>
                            <th class="text-center">Nama Bank </th>
                            <th class="text-center">No Rekening </th>
                            <th class="text-center">Penerima </th>
                            <th class="text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="text-align: center"><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php echo e($data->user->name); ?>

                            </td>
                            <td>
                                <?php echo e($data->departement->nama_departement); ?>

                            </td>
                            <td>
                                <?php echo e($data->payment); ?>

                            </td>
                            <td>
                                <?php echo e($data->kpengajuan->name); ?> </td>
                            <td>
                                <?php echo e(number_format($data->jumlah_total, 0, ',', '.',)); ?>

                            </td>
                            <td>
                                <?php switch($data):
                                case ($data->norek_id == null): ?>
                                <span class="badge bg-info">
                                    <i data-feather='dollar-sign'></i>
                                    Cash
                                </span>
                                <?php break; ?>
                                <?php default: ?>
                                <?php echo e($data->norek->bank->nama_bank); ?>

                                <?php endswitch; ?>
                            </td>
                            <td>
                                <?php switch($data):
                                case ($data->norek_id == null): ?>
                                <span class="badge bg-info">
                                    <i data-feather='dollar-sign'></i>
                                    Cash
                                </span>
                                <?php break; ?>
                                <?php default: ?>
                                <?php echo e($data->norek->no_rekening); ?> <?php endswitch; ?>
                            </td>
                            <td>
                                <?php switch($data):
                                case ($data->norek_id == null): ?>
                                <span class=" badge bg-info">
                                    <i data-feather='dollar-sign'></i>
                                    Cash
                                </span>
                                <?php break; ?>
                                <?php default: ?>
                                <?php echo e($data->norek->nama_penerima); ?>

                                <?php endswitch; ?>
                            </td>
                            <td class="text-center">
                                <?php switch($data):
                                case ($data->status == null): ?>
                                <span class="badge bg-secondary">Pending</span>
                                <?php break; ?>
                                <?php case ($data->status == 4): ?>
                                <a href="<?php echo e(route('form-approve.view', $data->id)); ?>"
                                    class="btn btn-icon btn-success btn-sm" data-bs-toggle="tooltip"
                                    data-bs-placement="top" data-bs-custom-class="tooltip-success"
                                    data-bs-original-title="Konfimasi Transaksi">
                                    <span class="ti ti-eye"></span>
                                </a>
                                <?php break; ?>
                                <?php case ($data->status == 5): ?>
                                <span class="badge bg-secondary">Menunggu Konfirmasi Dana Masuk</span>
                                <?php break; ?>
                                <?php case ($data->status == 6): ?>
                                <span class="badge bg-primary">Menunggu Konfirmasi Pembayaran</span>
                                <?php break; ?>
                                <?php case ($data->status == 7): ?>
                                <a href="<?php echo e(route('form-approve.viewDetail', $data->id)); ?>"
                                    class="btn btn-icon btn-secondary btn-sm" data-bs-toggle="tooltip"
                                    data-bs-placement="top" data-bs-custom-class="tooltip-secondary"
                                    data-bs-original-title="Cek Pengembalian">
                                    <span class="ti ti-eye"></span>
                                </a>
                                <a href="<?php echo e(url('approve/paid', $data->id)); ?>" class="btn btn-icon btn-success btn-sm"
                                    data-bs-toggle="tooltip" data-bs-placement="top"
                                    data-bs-custom-class="tooltip-success" data-bs-original-title="Konfirmasi">
                                    <span class="ti ti-check"></span>
                                </a>
                                <?php break; ?>
                                <?php default: ?>
                                <a href="<?php echo e(url('form/print', $data->id)); ?>" target="_blank">
                                    <i class="menu-icon tf-icons ti ti-download"></i>
                                </a> &nbsp;
                                <span class="badge bg-success">PAID</span>
                                <?php endswitch; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /Invoice table -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel\frequest\resources\views/pages/form/selesai/index.blade.php ENDPATH**/ ?>