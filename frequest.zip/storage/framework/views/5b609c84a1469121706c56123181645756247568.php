<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Form'); ?>
<div class="col-12">
    <div class="card">
        <div class="card-body mt-2">
            <div class="row mb-3" style="text-align right">
                <div class="col-auto me-auto ">
                    <h5 class="mb-0">PENGAJUAN DANA</h5>
                </div>
                <div class="col-auto">
                    <a href="<?php echo e(route('form-approve.index')); ?>" class="btn btn-secondary">Back</a>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-7 col-12">
                    <dl class="row mb-0">
                        <dt class="col-sm-4 fw-bolder mb-1"> Dari </dt>
                        <dd class="col-sm-8 mb-1"> <?php echo e($show->user->name); ?></dd>

                        <dt class="col-sm-4 fw-bolder mb-1">Departement</dt>
                        <dd class="col-sm-8 mb-1"> <?php echo e($show->departement->nama_departement); ?></dd>

                        <dt class="col-sm-4 fw-bolder mb-1">Payment</dt>
                        <dd class="col-sm-8 mb-1"> <?php echo e($show->payment); ?></dd>

                        <dt class="col-sm-4 fw-bolder mb-1">Tgl Kebutuhan</dt>
                        <dd class="col-sm-8 mb-1"> <?php echo e(\Carbon\Carbon::parse($show->tanggal_kebutuhan)->format('d-m-Y')); ?>

                        </dd>

                        <?php switch($show):
                        case ($show->payment == 'Transfer'): ?>
                        <dt class="col-sm-4 fw-bolder mb-1">Nomor Rekening</dt>
                        <dd class="col-sm-8 mb-1"> <?php echo e($show->norek->no_rekening); ?></dd>
                        <?php break; ?>
                        <?php default: ?>
                        <?php endswitch; ?>
                        <?php switch($show):
                        case ($show->payment == 'Transfer'): ?>
                        <dt class="col-sm-4 fw-bolder mb-1">Bank</dt>
                        <dd class="col-sm-8 mb-1"> <?php echo e($show->norek->bank->nama_bank); ?></dd>
                        <?php break; ?>
                        <?php default: ?>
                        <?php endswitch; ?>
                        <?php switch($show):
                        case ($show->payment == 'Transfer'): ?>
                        <dt class="col-sm-4 fw-bolder mb-1">A/n</dt>
                        <dd class="col-sm-8 mb-1"> <?php echo e($show->norek->nama_penerima); ?></dd>
                        <?php break; ?>
                        <?php default: ?>
                        <?php endswitch; ?>
                    </dl>
                </div>
                <div class="col-xl-5 col-12">
                    <dl class="row mb-0">
                        <dt class="col-sm-4 fw-bolder mb-1">Pengajuan</dt>
                        <dd class="col-sm-8 mb-1"> <?php echo e($show->kpengajuan->name); ?></dd>

                        <dt class="col-sm-4 fw-bolder mb-1">Untuk</dt>
                        <dd class="col-sm-8 mb-1"> <?php echo e($show->rujukan->name); ?></dd>

                        <dt class="col-sm-4 fw-bolder mb-1">Keperluan</dt>
                        <dd class="col-sm-8 mb-1"> <?php echo e($show->keperluan->name); ?></dd>
                        <?php switch($show):
                        case ($show->keperluan_id == 1): ?>
                        <dt class="col-sm-4 fw-bolder mb-1">No Project</dt>
                        <dd class="col-sm-8 mb-1"> <?php echo e($show->no_project); ?></dd>

                        <dt class="col-sm-4 fw-bolder mb-1">Jumlah Peserta</dt>
                        <dd class="col-sm-8 mb-1"> <?php echo e($show->j_peserta); ?></dd>

                        <dt class="col-sm-4 fw-bolder mb-1">Jumlah Trainer/Asesor</dt>
                        <dd class="col-sm-8 mb-1"> <?php echo e($show->j_traine_asesor); ?></dd>

                        <dt class="col-sm-4 fw-bolder mb-1">Jumlah Assist</dt>
                        <dd class="col-sm-8 mb-1"> <?php echo e($show->j_assist); ?></dd>
                        <?php break; ?>
                        <?php default: ?>
                        <?php endswitch; ?>



                    </dl>
                </div>
                <div class="table-responsive mt-2">
                    <table class="table table-bordered">
                        <thead>
                            <tr width='20px' style="background-color:skyblue">
                                <th width='20px'>No</th>
                                <th>Description</th>
                                <th>Qty</th>
                                <th>Unit</th>
                                <th>Lampiran</th>
                                <th class="text-center" style="text-align center">Unit Price (Rp)</th>
                                <th class="text-center" style="text-align center">Sub Total (Rp)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td><?php echo e($show->description); ?> </td>
                                <td><?php echo e($show->qty); ?></td>
                                <td><?php echo e($show->unit); ?></td>
                                <td>
                                    <?php switch($show):
                                    case ($show->image1 == 0): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <a href="<?php echo e(url('form/download/' . $show->image1)); ?>" target="_blank"
                                        class="text-primary font-weight-bold"> <i data-feather="download"></i>
                                        <?php echo e($show->image1); ?>

                                    </a>
                                    <?php endswitch; ?>
                                </td>
                                <td style="text-align :right"> <?php echo e(number_format($show->price, 0, ',', '.',)); ?>

                                </td>
                                <td style="text-align :right"><?php echo e(number_format($show->total, 0, ',', '.')); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td><?php echo e($show->description2); ?> </td>
                                <td><?php echo e($show->qty2); ?></td>
                                <td><?php echo e($show->unit2); ?></td>
                                <td>
                                    <?php switch($show):
                                    case ($show->image2 == 0): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <a href="<?php echo e(url('form/download/' . $show->image2)); ?>" target="_blank"
                                        class="text-primary font-weight-bold"> <i data-feather="download"></i>
                                        <?php echo e($show->image2); ?>

                                    </a>
                                    <?php endswitch; ?>
                                </td>

                                </td>
                                <td style="text-align :right">
                                    <?php switch($show):
                                    case ($show->price2 == null): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <?php echo e(number_format($show->price2, 0, ',', '.')); ?>

                                    <?php endswitch; ?> </td>
                                <td style="text-align :right">
                                    <?php switch($show):
                                    case ($show->total2 == '0'): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <?php echo e(number_format($show->total2, 0, ',', '.')); ?>

                                    <?php endswitch; ?>
                                </td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td><?php echo e($show->description3); ?> </td>
                                <td><?php echo e($show->qty3); ?></td>
                                <td><?php echo e($show->unit3); ?></td>
                                <td>
                                    <?php switch($show):
                                    case ($show->image3 == 0): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <a href="<?php echo e(url('form/download/' . $show->image3)); ?>" target="_blank"
                                        class="text-primary font-weight-bold"> <i data-feather="download"></i>
                                        <?php echo e($show->image3); ?>

                                    </a>
                                    <?php endswitch; ?>
                                </td>
                                <td style="text-align :right">
                                    <?php switch($show):
                                    case ($show->price3 == null): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <?php echo e(number_format($show->price3, 0, ',', '.')); ?>

                                    <?php endswitch; ?> </td>
                                <td style="text-align :right">
                                    <?php switch($show):
                                    case ($show->total3 == '0'): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <?php echo e(number_format($show->total3, 0, ',', '.')); ?>

                                    <?php endswitch; ?>
                                </td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td><?php echo e($show->description4); ?> </td>
                                <td><?php echo e($show->qty4); ?></td>
                                <td><?php echo e($show->unit4); ?></td>
                                <td>
                                    <?php switch($show):
                                    case ($show->image4 == 0): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <a href="<?php echo e(url('form/download/' . $show->image4)); ?>" target="_blank"
                                        class="text-primary font-weight-bold"> <i data-feather="download"></i>
                                        <?php echo e($show->image4); ?>

                                    </a>
                                    <?php endswitch; ?>
                                </td>
                                <td style="text-align :right">
                                    <?php switch($show):
                                    case ($show->price4 == null): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <?php echo e(number_format($show->price4, 0, ',', '.')); ?>

                                    <?php endswitch; ?>
                                </td>
                                <td style="text-align :right">
                                    <?php switch($show):
                                    case ($show->total4 == '0'): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <?php echo e(number_format($show->total4, 0, ',', '.')); ?>

                                    <?php endswitch; ?>
                                </td>
                            </tr>
                            <tr>
                                <td>5</td>
                                <td><?php echo e($show->description5); ?> </td>
                                <td><?php echo e($show->qty5); ?></td>
                                <td><?php echo e($show->unit5); ?></td>
                                <td>
                                    <?php switch($show):
                                    case ($show->image5 == 0): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <a href="<?php echo e(url('form/download/' . $show->image5)); ?>" target="_blank"
                                        class="text-primary font-weight-bold"> <i data-feather="download"></i>
                                        <?php echo e($show->image5); ?>

                                    </a>
                                    <?php endswitch; ?>
                                </td>
                                <td style="text-align :right">
                                    <?php switch($show):
                                    case ($show->price5 == null): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <?php echo e(number_format($show->price5, 0, ',', '.')); ?>

                                    <?php endswitch; ?>
                                </td>
                                <td style="text-align :right">
                                    <?php switch($show):
                                    case ($show->total5 == '0'): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <?php echo e(number_format($show->total5, 0, ',', '.')); ?>

                                    <?php endswitch; ?>
                                </td>
                            </tr>
                            <tr>
                                <td>6</td>
                                <td><?php echo e($show->description6); ?> </td>
                                <td><?php echo e($show->qty6); ?></td>
                                <td><?php echo e($show->unit6); ?></td>
                                <td>
                                    <?php switch($show):
                                    case ($show->image6 == 0): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <a href="<?php echo e(url('form/download/' . $show->image6)); ?>" target="_blank"
                                        class="text-primary font-weight-bold"> <i data-feather="download"></i>
                                        <?php echo e($show->image6); ?>

                                    </a>
                                    <?php endswitch; ?>
                                </td>
                                <td style="text-align :right">
                                    <?php switch($show):
                                    case ($show->price6 == null): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <?php echo e(number_format($show->price6, 0, ',', '.')); ?>

                                    <?php endswitch; ?>
                                </td>
                                <td style="text-align :right">
                                    <?php switch($show):
                                    case ($show->total6 == '0'): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <?php echo e(number_format($show->total6, 0, ',', '.')); ?>

                                    <?php endswitch; ?>
                                </td>
                            </tr>
                            <tr>
                                <td>7</td>
                                <td><?php echo e($show->description7); ?> </td>
                                <td><?php echo e($show->qty7); ?></td>
                                <td><?php echo e($show->unit7); ?></td>
                                <td>
                                    <?php switch($show):
                                    case ($show->image7 == 0): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <a href="<?php echo e(url('form/download/' . $show->image7)); ?>" target="_blank"
                                        class="text-primary font-weight-bold"> <i data-feather="download"></i>
                                        <?php echo e($show->image7); ?>

                                    </a>
                                    <?php endswitch; ?>
                                </td>
                                <td style="text-align :right">
                                    <?php switch($show):
                                    case ($show->price7 == null): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <?php echo e(number_format($show->price7, 0, ',', '.')); ?>

                                    <?php endswitch; ?>
                                </td>
                                <td style="text-align :right">
                                    <?php switch($show):
                                    case ($show->total7 == '0'): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <?php echo e(number_format($show->total7, 0, ',', '.')); ?>

                                    <?php endswitch; ?>
                                </td>
                            </tr>
                            <tr>
                                <td>8</td>
                                <td><?php echo e($show->description8); ?> </td>
                                <td><?php echo e($show->qty8); ?></td>
                                <td><?php echo e($show->unit8); ?></td>
                                <td>
                                    <?php switch($show):
                                    case ($show->image8 == 0): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <a href="<?php echo e(url('form/download/' . $show->image8)); ?>" target="_blank"
                                        class="text-primary font-weight-bold"> <i data-feather="download"></i>
                                        <?php echo e($show->image8); ?>

                                    </a>
                                    <?php endswitch; ?>
                                </td>
                                <td style="text-align :right">
                                    <?php switch($show):
                                    case ($show->price8 == null): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <?php echo e(number_format($show->price8, 0, ',', '.')); ?>

                                    <?php endswitch; ?>
                                </td>
                                <td style="text-align :right">
                                    <?php switch($show):
                                    case ($show->total8 == '0'): ?>
                                    <?php break; ?>
                                    <?php default: ?>
                                    <?php echo e(number_format($show->total8, 0, ',', '.')); ?>

                                    <?php endswitch; ?>
                                </td>
                            </tr>
                            <?php switch($show):
                            case ($show->payment == 'Transfer'): ?>
                            <tr style="color:black; background-color: lightgreen">
                                <th colspan="6" style="text-align :right ">Biaya Admin</th>
                                <td style="text-align :right">
                                    <?php echo e(number_format($show->b_admin, 0, ',',
                                    '.')); ?>

                                </td>
                            </tr>
                            <tr style="color:black; background-color: lightgreen">
                                <th colspan="6" style="text-align :right ">TOTAL</th>
                                <td style="text-align :right"> <?php echo e(number_format($show->jumlah_total, 0, ',',
                                    '.')); ?></td>
                            </tr>
                            <?php break; ?>
                            <?php default: ?>
                            <tr style="color:black; background-color: lightgreen">
                                <th colspan="6" style="text-align :right ">TOTAL</th>
                                <td style="text-align :right"> <?php echo e(number_format($show->jumlah_total, 0, ',',
                                    '.')); ?></td>
                            </tr>
                            <?php endswitch; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!--/ Billing Address -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel\frequest\resources\views/pages/form/approve/detail.blade.php ENDPATH**/ ?>